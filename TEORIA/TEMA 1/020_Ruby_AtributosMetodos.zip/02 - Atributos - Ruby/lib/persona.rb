#encoding: UTF-8

class Persona

  @@atributoclase = "Atributo clase"
  @nombre = "Atributo de instancia de la clase"
  
  def initialize(nombre, edad)
    @nombre = nombre
    @edad = edad
    @direccion = "Gran via"
  end

  def to_s
    puts @direccion
    puts @@atributoclase
  end
  
  def metodoInstancia
    puts "metodo de instancia"
  end
  
  def self.metodoClase
    puts "metodo de clase"
  end
  
  private_class_method metodoClase
  
end

p = Persona.new("Fulano", 34)
  #en java: Persona p = new Persona("fulano", 34);

p.metodoInstancia
#p.metodoClase ERROR! <-- En Java funciona!
#Persona.metodoInstancia - Error!
Persona.metodoClase


