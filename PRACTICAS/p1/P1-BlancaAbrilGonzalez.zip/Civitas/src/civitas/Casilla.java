/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package civitas;

/**
 *
 * @author Blanca
 */
public class Casilla {
    private TipoCasilla tipo;
    private String nombre;
    private float precioCompra, precioEdificar, precioBaseAlquiler;
    private int numCasas, numHoteles;
    public static float FACTORALQUILERCALLE = 1.0f;
    public static float FACTORALQUILERCASA = 1.0f;
    public static float FACTORALQUILERHOTEL = 4.0f;
    
    // Constructor por parámetros
    
    public Casilla (TipoCasilla unTipo, String unNombre, float unPrecioCompra, float unPrecioEdificar, float unPrecioAlquilerBase){
        this.tipo = unTipo;
        this.nombre = unNombre;
        
        this.precioCompra = unPrecioCompra;
        this.precioEdificar = unPrecioEdificar;
        this.precioBaseAlquiler = unPrecioAlquilerBase;
        
        this.numCasas = 0;
        this.numHoteles = 0;
    }
    
    // Devuelve el tipo de casilla
    public TipoCasilla getTipo(){
        return this.tipo;
    }
    
    // Devuelve el nombre de la casilla
    public String getNombre(){
        return nombre;
    }
    
    // Devuelve el precio de compra de la casilla
    public float getPrecioCompra(){
        return precioCompra;
    }
    
    // Devuelve el numero de casas que tiene la casilla
    public int getNumCasas(){
        return numCasas;
    }
    
    // Devuelve el numero de hoteles que tiene la casilla
    public int getNumHoteles(){
        return numHoteles;
    }
    
    // Devuelve el precio del alquiler completo de la casilla
    public float getPrecioAlquilerCompleto(){
        float precio_alquiler = precioBaseAlquiler * (FACTORALQUILERCALLE * (FACTORALQUILERCASA + numCasas + (FACTORALQUILERHOTEL*numHoteles)));
        return precio_alquiler;
    }
    
    // Imprime toda la información sobre la casilla
    public String toString() {
        return " Calle " + nombre + ". \n " + "Precios: " + precioCompra + "\n Edificar " + precioEdificar + "\n Alquiler base: " + precioBaseAlquiler 
                + "\n Casas: " + numCasas + "\n Hoteles: " + numHoteles + "";
    } 
    
}
